﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenIZ.Mobile.Core.Data.Model.DataType
{
    /// <summary>
    /// Dummy class for bundles
    /// </summary>
    public class DbBundle : DbIdentified
    {
    }
}
