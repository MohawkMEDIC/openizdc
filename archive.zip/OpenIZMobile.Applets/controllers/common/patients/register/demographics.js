﻿/// <refernece path="~/js/openiz.js"/>
/// <reference path="~/js/openiz-model.js"/>
/// <reference path="~/lib/jquery.min.js"/>
/// <reference path="~/lib/angular.min.js"/>
/// <reference path="~/lib/select2.min.js"/>

angular.element(document).ready(function () {


   


    //$('.select2-tag').each(function (e, d) {
    //    $(d).on('select2:open', function (s) {
    //        s.preventDefault();
    //        return true;
    //    });
    //});

});