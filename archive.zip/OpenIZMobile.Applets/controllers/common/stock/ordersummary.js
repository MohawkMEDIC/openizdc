﻿/// <reference path="../js/openiz-model.js"/>

/*
 * Copyright 2016 PATH International
 * Developed by Mohawk College of Applied Arts and Technology 
 *
 * Licensed under Creative Commons ShareAlike Attribution Version 4.0 (the "License"); 
 * you may not use this file except in compliance with the License. You may 
 * obtain a copy of the License at 
 * 
 * https://creativecommons.org/licenses/by-sa/4.0/legalcode
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the 
 * License for the specific language governing permissions and limitations under 
 * the License.
 * 
 * User: khannan
 * Date: 2016-9-9
 */

/// <reference path="../js/openiz.js"/>

layoutApp.controller('OrderSummaryController', ['$scope', function ($scope) {

    var labels = [];
    var data = [];
    labels[0] = OpenIZ.Localization.getString("locale.stock.released");
    labels[1] = OpenIZ.Localization.getString("locale.stock.cancelled");
    labels[2] = OpenIZ.Localization.getString("locale.stock.requested");
    labels[3] = OpenIZ.Localization.getString("locale.stock.shipped");
    labels[4] = OpenIZ.Localization.getString("locale.stock.packed");
    data[0] = 3;
    data[1] = 4;
    data[2] = 2;
    data[3] = 6;
    data[4] = 1;


    var ctxOrders = document.getElementById("orderSummaryChart");
    var myChart = new Chart(ctxOrders, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                label: OpenIZ.Localization.getString("locale.stock.stockStatusDoses"),
                data: data,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
    });

}]);
